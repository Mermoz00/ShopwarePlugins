# Shopware (6) 3D-Produktbilder Plugin

Ein Shopware (6) Plugin, welches dir erlaubt ein 3D-Bild / 3D-Ansicht zu einem Produkt hinzuzufügen.
