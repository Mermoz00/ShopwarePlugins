import './module/bal-three';

import './extension/sw-product/view/sw-product-detail-base';
import './extension/sw-product/page/sw-product-detail';
