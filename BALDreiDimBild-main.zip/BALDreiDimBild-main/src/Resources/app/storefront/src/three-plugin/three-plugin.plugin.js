import Plugin from 'src/plugin-system/plugin.class';

export default class ThreePlugin extends Plugin {
    init() {
        //hier Js Code
    }
}
