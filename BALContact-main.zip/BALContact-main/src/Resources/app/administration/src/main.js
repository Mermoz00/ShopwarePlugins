import './module/bal-contact';

import './extension/sw-product/view/sw-product-detail-base';
import './extension/sw-product/page/sw-product-detail';
