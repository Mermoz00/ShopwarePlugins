# Plugin: Cart Also Bought

Dieses Plugin fügt ebenfalls gekaufte Artikel in den Warenkorb hinzu.
