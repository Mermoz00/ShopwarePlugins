<?php declare(strict_types=1);

namespace BAL\ProductRequestForm;

use Shopware\Core\Framework\Plugin;

class ProductRequestForm extends Plugin
{
}
