# Shopware (5) 3D-Produktbilder Plugin

Ein Shopware (5) Plugin, welches dir erlaubt ein 3D-Bild / 3D-Ansicht zu einem Produkt hinzuzufügen.
