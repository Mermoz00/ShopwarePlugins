# BALCmsBlockExtensions

## Shopware 6 Plugin

Das Plugin ergänzt die SW6 Erlebniswelten um zwei zusätzliche Text-Image Blöcke.
Vorhanden sind die Varianten mit Bild-links und Bild-rechts.
Das Bild nimmt jeweils 25% der Zeile ein, der Text den Rest.
