import { Component } from 'src/core/shopware';
import template from './sw-cms-block-text-image-reversed.html.twig';
import './sw-cms-block-text-image-reversed.scss';

Component.register('sw-cms-block-text-image-reversed', {
    template
});
