import { Component } from 'src/core/shopware';
import template from './sw-cms-block-image-text-reversed.html.twig';
import './sw-cms-block-image-text-reversed.scss';

Component.register('sw-cms-block-image-text-reversed', {
    template
});
