<?php declare(strict_types=1);

namespace BAL\CmsBlockExtension;

use Shopware\Core\Framework\Plugin;

class CmsBlockExtension extends Plugin
{
}
